CREATE TABLE Person (
    PersonID NUMBER(20) PRIMARY KEY,
    FirstName VARCHAR2(100),
    LastName VARCHAR2(100),
    Gender VARCHAR2(10),
    DateOfBirth NUMBER(8),
    StreetAddress VARCHAR2(200),
    CityAddress VARCHAR2(100),
    Province VARCHAR2(100),
    Occupation VARCHAR2(100)
);

CREATE TABLE Passenger (
    PassengerID NUMBER(20) PRIMARY KEY,
    Type VARCHAR2(100),
    TypeID NUMBER(20)
);

CREATE TABLE Type (
    TypeID NUMBER(20) PRIMARY KEY,
    TypeName VARCHAR2(100),
    Amount NUMBER(20)
);


CREATE TABLE Bus_Driver (
    DriverID NUMBER(20) PRIMARY KEY,
    Salary NUMBER(20),
    YearsOfService NUMBER(20)
);

CREATE TABLE DrivingInfraction (
    InfractionID NUMBER(20) PRIMARY KEY,
    DriverID NUMBER(20),
    "Date" DATE,  -- Enclosed "Date" in double quotes
    TypeOfInfraction VARCHAR2(100),
    DemeritPoints NUMBER(20),
    FinancialPenalty NUMBER(20)
);

CREATE TABLE MaintenancePersonnel (
    MaintenanceID NUMBER PRIMARY KEY,
    BusID NUMBER,
    AreaSpecialization VARCHAR2(100),
    YearsOfService NUMBER,
    Salary NUMBER(20,2)
);

CREATE TABLE Bus (
    BusID NUMBER(20) PRIMARY KEY,
    YearsInOperation NUMBER(20),
    NumberOfSeats NUMBER(20),
    Manufacturer VARCHAR2(100),
    AdvertisingRevenue NUMBER(20),
    FuelType VARCHAR2(50),
    RouteID NUMBER(20)
);

CREATE TABLE Route (
    RouteID NUMBER(20) PRIMARY KEY,
    Name VARCHAR2(100)
);

CREATE TABLE Stop (
    StopID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    RouteID NUMBER
);

CREATE TABLE Schedule (
    ScheduleID NUMBER PRIMARY KEY,
    BusID NUMBER,
    StopID NUMBER,
    RouteID NUMBER,
    ArrivalTime TIMESTAMP,
    "Date" DATE
);

CREATE TABLE Site (
    SiteID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Address VARCHAR2(200),
    PhoneNumber VARCHAR2(15),
    Capacity NUMBER,
    Category VARCHAR2(100)
);

CREATE TABLE Event (
    EventID NUMBER PRIMARY KEY,
    SiteID NUMBER,
    Name VARCHAR2(100),
    DateTime TIMESTAMP,
    ExpectedNumberOfParticipants NUMBER
);

CREATE TABLE RouteStop (
    RouteStopID NUMBER PRIMARY KEY,
    RouteID NUMBER,
    StopID NUMBER
);

CREATE TABLE StopSite (
    StopSiteID NUMBER PRIMARY KEY,
    StopID NUMBER,
    SiteID NUMBER
);


CREATE TABLE RouteSite (
    RouteSiteID NUMBER PRIMARY KEY,
    RouteID NUMBER,
    SiteID NUMBER
);










